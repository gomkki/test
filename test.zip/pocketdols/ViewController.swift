//
//  ViewController.swift
//  pocketdolsTest
//
//  Created by Bigband on 2022/10/31.
//

import UIKit
import CallKit
import PushKit
import AVKit

struct Call {
    enum EndReason {
        case general
        case timeOut
        case error
        case exitAll
        case callAgain
        case nextCall
        case force
        case noPermissions
        case mayDifferentServer
        var parameter:String {
            switch self {
                case .general:
                    return "end"
                case .timeOut:
                    return "timeout"
                case .error:
                    return "error"
                case .exitAll:
                    return "exit"
                case .callAgain:
                    return "recall"
                case .nextCall:
                    return "next"
                case .force:
                    return "force"
                case .noPermissions:
                    return "noPermissions"
                case .mayDifferentServer:
                    return "mayDifferentServer"
                    //                default :
                    //                    return "end"
            }
        }
    }
    
    private(set) var uuid: UUID
    //    let handle: String
    //    let roomName: String?
    //    let partnerId: String
    let userInfo: RtcUserInfo?
    var me: RtcUserInfo?
}
class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}

class CallManager: NSObject, CXProviderDelegate {
    static var shared = CallManager()
    private let voipRegistry = PKPushRegistry(queue: nil)
    fileprivate(set) var currentCall: Call? = nil
    fileprivate let provider: CXProvider
    
    fileprivate static var providerConfiguration: CXProviderConfiguration = {
        if #available(iOS 14.0, *) {
            let providerConfiguration = CXProviderConfiguration() //CXProviderConfiguration(localizedName: "Pocketdols")
            providerConfiguration.supportsVideo = true
            
            providerConfiguration.includesCallsInRecents = true // 최근 통화 목록에 내역 남김
            providerConfiguration.maximumCallsPerCallGroup = 1
            providerConfiguration.supportedHandleTypes = [.generic]
            if let iconData = UIImage(named: "icon_pocketdols_callkit")?.pngData() {
                providerConfiguration.iconTemplateImageData = iconData
            }
            return providerConfiguration
        }
        else {
            let providerConfiguration = CXProviderConfiguration(localizedName: "Pocketdols")
            providerConfiguration.supportsVideo = true
            
            providerConfiguration.includesCallsInRecents = true // 최근 통화 목록에 내역 남김
            providerConfiguration.maximumCallsPerCallGroup = 1
            providerConfiguration.supportedHandleTypes = [.generic]
            if let iconData = UIImage(named: "icon_pocketdols_callkit")?.pngData() {
                providerConfiguration.iconTemplateImageData = iconData
            }
            return providerConfiguration
        }
    }()
    
    private override init() {
        provider = CXProvider(configuration: CallManager.providerConfiguration)
//        callController = CXCallController()
        super.init()
        provider.setDelegate(self, queue: nil)
    }
    
    func voipPushInit(){
        voipRegistry.delegate = self
        voipRegistry.desiredPushTypes = [.fileProvider, .voIP]
    }
    // MARK: - CXProviderDelegate
    func providerDidReset(_ provider: CXProvider) {
        print("Provider did reset")
        
    }
    
    func provider(_ provider: CXProvider, perform action: CXStartCallAction) {
        print("call start action")
        action.fulfill()
    }
    
    func provider(_ provider: CXProvider, perform action: CXAnswerCallAction) {
        print("call answer action")
        action.fulfill()
    }
    
    func provider(_ provider: CXProvider, perform action: CXEndCallAction) {
        print("call end action")
        action.fulfill()
    }
    
    func provider(_ provider: CXProvider, timedOutPerforming action: CXAction) {
        //        print(#function)
        action.fulfill()
    }
    
    func provider(_ provider: CXProvider, didActivate audioSession: AVAudioSession) {
        print("active audio action")
    }
    
    func provider(_ provider: CXProvider, didDeactivate audioSession: AVAudioSession) {
        print("deactive audio action")
    }
    
    func provider(_ provider: CXProvider, perform action: CXSetMutedCallAction) {
        print("audio mute action")
        action.fulfill()
    }
    
    func provider(_ provider: CXProvider, perform action: CXSetHeldCallAction) {
        //        fatalError("Not Implemented")
        action.fulfill()
    }
}

extension CallManager: PKPushRegistryDelegate{
    func pushRegistry(_ registry: PKPushRegistry, didUpdate pushCredentials: PKPushCredentials, for type: PKPushType) {
        let voipToken = (pushCredentials.token.map { data in String(format: "%02.2hhx", data) }).joined()
        print ("voip token : ", voipToken)
    }
    
    func pushRegistry(_ registry: PKPushRegistry,
                      didReceiveIncomingPushWith payload: PKPushPayload,
                      for type: PKPushType,
                      completion: @escaping () -> Void) {
        CallManager.shared.voipPushInit()
        

        let bgTaskID = UIApplication.shared.beginBackgroundTask() {
            print("beginBackgroundTask is expired")
        }
        
        let key = "VoipPushReceived"
        let sn = UserDefaults.standard.integer(forKey: key)
        UserDefaults.standard.set((sn ) + 1, forKey: key)
        print(">>>>>>>>> received Push (\(UserDefaults.standard.integer(forKey: key) ) )")
        print ("payloadDic : ", payload.dictionaryPayload)
        if type == .voIP {
            let payloadDic = payload.dictionaryPayload
            let status  = payloadDic["status"] as? String //VideoCallStatus(rawValue: (payloadDic["status"] as? String) ?? "")
            let uuidString = payloadDic["uuid"] as? String
            
            switch status {
                case  "Missed": //.missed :
                    let missedUUID = UUID(uuidString: uuidString ?? "") ?? UUID()
                    
                    if #available(iOS 13.0.0, *) {
                        Task.init(priority: .high) {
                            provider.reportCall(with: missedUUID, endedAt: nil, reason: .unanswered)
                            print("missedUUID : ", missedUUID.uuidString)
                            completion()
                        }
                    }
                    else {
                        provider.reportCall(with: missedUUID, endedAt: nil, reason: .unanswered)
                        print("missedUUID : ", missedUUID.uuidString)
                        completion()
                    }
                    break;
               
                    
                case "Incomming" : //.incomming :
                    let userDic = payloadDic["fromUser"]
                    let userInfo = RtcUserInfo.create(from: [userDic ?? []])

                    let toUserDic = payloadDic["toUser"]
                    let toUserInfo = RtcUserInfo.create(from: [toUserDic ?? []])

                    
                    let callUUID = UUID(uuidString: uuidString ?? "") ?? UUID()
                    
                    let call = Call(uuid: callUUID, userInfo: userInfo, me: toUserInfo)
                    self.currentCall = call
                    
                    let callUpdate = CXCallUpdate()
                    callUpdate.remoteHandle = CXHandle(type: .generic, value: call.userInfo?.mb_nick ?? "unknown")
                    callUpdate.hasVideo = true
                    callUpdate.supportsHolding = false

                    if #available(iOS 13.0.0, *) {
                        Task.init(priority: .high) {
                            do {
                                try await provider.reportNewIncomingCall(
                                    with: callUUID, //UUID(),
                                    update: callUpdate)
                                completion()
                            }
                            catch {
                                print("reportNewIncomingCall error : ", error.localizedDescription)
                                completion()
                            }
                        }
                    }
                    else {
                        provider.reportNewIncomingCall(
                            with: callUUID, //UUID(),
                            update: callUpdate,
                            completion: { _ in
                                completion()
                            })
                    }
                    
                    break;
                default:
                    print(#line, #file , #function, "received push : ", status as Any)
                    print("  complete 3) ->  (\(UserDefaults.standard.integer(forKey: key) ) )")
                    completion()
                    break;
            }
            
        }
        
        UIApplication.shared.endBackgroundTask(bgTaskID)
    }
}



struct RtcUserInfo {
    //    private(set) var socketId:String?
    let mb_no: Int64 //String?
    private(set) var mb_nick:String?
    private(set) var callingName:String?
    private(set) var room:String?
    private(set) var userType:String? // observer = 1, artist = 2, user = 3
    private(set) var status:String?
    private(set) var isStartedCall:Bool?
    private(set) var duration:Int?
    private(set) var limitTime:Int?
    
    private(set) var totalDuration:Int?
    
    
    private(set) var profileImage:String?
    private(set) var eventTime:String? // 비디오 콜 예정 시간
    
    var isStartFromBeginning:Bool = false
    var isConnectedUser:Bool?
}

extension RtcUserInfo{
    static func create(from payloadDic: [String: Any]) -> RtcUserInfo? {
        let mbNoString = (payloadDic["from_mb_no"] as? String) ?? (payloadDic["mb_no"] as? String) ?? ""
        guard let mbNo = (payloadDic["from_mb_no"] as? Int64) ?? (payloadDic["mb_no"] as? Int64) ?? Int64(mbNoString)else {
            print(#line, #file , #function, "Can not found \"mb_no\". ")
            return nil
        }
        
        let status = payloadDic["status"] as? String
        let mbNick = payloadDic["mb_nick"] as? String ?? payloadDic["mbNick"] as? String
        let intUserType = (payloadDic["fromUserType"] as? Int) ?? (payloadDic["userType"] as? Int)
        let userType = (intUserType != nil) ? "\(intUserType ?? 0)" :   ((payloadDic["fromUserType"] as? String) ?? (payloadDic["userType"] as? String))
        let roomName = payloadDic["room"] as? String
        let isStartedCall = payloadDic["startCall"] as? Bool
        let callDuration = payloadDic["duration"] as? Int
        let callLimitedTime = payloadDic["limit_call_time"] as? Int
        let profileImage = payloadDic["img"] as? String
        
        //        let bonusTime = payloadDic["bonus_time"] as? Int
        let eventTime = payloadDic["scheduleTime"] as? String
        
        let callingName = payloadDic["call_name"] as? String
        let totalDuration = payloadDic["total_duration"] as? Int
        
        return RtcUserInfo(mb_no: mbNo, //(mbNo == nil) ? nil : "\(mbNo ?? 0)",
                           mb_nick: mbNick,
                           callingName:callingName,
                           room: roomName,
                           userType: userType,
                           status: status,
                           isStartedCall: isStartedCall,
                           duration: callDuration,
                           limitTime: callLimitedTime,
                           totalDuration:totalDuration,
                           profileImage: profileImage,
                           eventTime: eventTime)
    }
    
    static func create(from socketData: [Any]) -> RtcUserInfo? {
        guard let payloadDictionary = socketData.first as? [String: Any] else {
            print(#line, #file , #function, "Unable to retrieve RtcUserInfo from socket message")
            return nil
        }
        
        return RtcUserInfo.create(from: payloadDictionary)
    }
    
    static func createUserList(from socketData: [Any]) -> [RtcUserInfo]? {
        guard let payloadArray = socketData.first as? Array<[String: Any]> else {
            print(#line, #file , #function, "Unable to retrieve RtcUserInfo from socket message")
            return nil
        }
        
        return payloadArray.compactMap{ payloadDictionary in
            return RtcUserInfo.create(from: payloadDictionary)
        }
    }
}
